/* Copyright (C) 2019 Mr Goldberg
   This file is part of the Goldberg Emulator

   The Goldberg Emulator is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 3 of the License, or (at your option) any later version.

   The Goldberg Emulator is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the Goldberg Emulator; if not, see
   <http://www.gnu.org/licenses/>.  */

// source: https://github.com/Detanup01/stmsrv/blob/main/Steam3Server/Others/AppTickets.cs
// thanks Detanup01

#ifndef AUTH_INCLUDE_H
#define AUTH_INCLUDE_H

#include "base.h"
#include "include.wrap.mbedtls.h"

#define STEAM_TICKET_MIN_SIZE  (4 + 8 + 8 + 4)
#define STEAM_TICKET_MIN_SIZE_NEW 170

// Steam recommends sending 1024 byte buffer. It returns 234 byte ticket.
#define STEAM_AUTH_TICKET_SIZE 1024

// the data type is important, we depend on sizeof() for each one of them
constexpr const static uint32_t STEAM_APPTICKET_SIGLEN = 128;
constexpr const static uint32_t STEAM_APPTICKET_GCLen = 20;
constexpr const static uint32_t STEAM_APPTICKET_SESSIONLEN = 24;


struct DLC {
    uint32_t AppId{};
    std::vector<uint32_t> Licenses{};

    std::vector<uint8_t> Serialize() const;
};

struct AppTicketGC {
    uint64_t GCToken{};
    CSteamID id{};
    uint32_t ticketGenDate{}; //epoch

public:
    std::vector<uint8_t> Serialize() const;
};

struct AppTicketSession {
    uint32_t ExternalIP{};
    uint32_t InternalIP{};
    uint32_t TimeSinceStartup{};
    uint32_t TicketGeneratedCount{};

private:
    uint32_t one = 1;
    uint32_t two = 2;

public:
    std::vector<uint8_t> Serialize() const;
};

struct AppTicket {
    uint32_t Version{};
    CSteamID id{};
    uint32_t AppId{};
    uint32_t ExternalIP{};
    uint32_t InternalIP{};
    uint32_t AlwaysZero = 0; //OwnershipFlags?
    uint32_t TicketGeneratedDate{};
    uint32_t TicketGeneratedExpireDate{};
    std::vector<uint32_t> Licenses{};
    std::vector<DLC> DLCs{};

    std::vector<uint8_t> Serialize() const;
};

struct Auth_Data {
    bool HasGC{};
    bool HasSession{};
    AppTicketGC GC{};
    AppTicketSession Session{};
    AppTicket Ticket{};
    //old data
    CSteamID id{};
    uint64_t number{};
    std::chrono::high_resolution_clock::time_point created{};

    std::vector<uint8_t> Serialize() const;
};



class Auth_Manager {
    class Settings *settings{};
    class Networking *network{};
    class SteamCallBacks *callbacks{};

    std::vector<struct Auth_Data> inbound{};
    std::vector<struct Auth_Data> outbound{};

    void launch_callback(CSteamID id, EAuthSessionResponse resp, double delay=0);
    void launch_callback_gs_steam2(CSteamID steam_id, uint32_t user_id, bool approved);
    void launch_callback_gs(CSteamID id, bool approved);

    static void ticket_callback(void *object, Common_Message *msg);
    void Callback(Common_Message *msg);

public:
    Auth_Manager(class Settings *settings, class Networking *network, class SteamCallBacks *callbacks);
    ~Auth_Manager();

    HAuthTicket getTicket( void *pTicket, int cbMaxTicket, uint32 *pcbTicket );
    HAuthTicket getWebApiTicket( const char *pchIdentity );
    void cancelTicket(uint32 number);

    Auth_Data validateTicket(const void *pAuthTicket, uint32 cbAuthTicket, CSteamID fallbackID, CSteamID *pSteamIDUser);
    EBeginAuthSessionResult beginAuth(const void *pAuthTicket, int cbAuthTicket, CSteamID steamID);
    bool endAuth(CSteamID id);

    uint32 countInboundAuth();

    bool SendSteam2UserConnect( uint32 unUserID, const void *pvRawKey, uint32 unKeyLen, uint32 unIPPublic, uint16 usPort, const void *pvCookie, uint32 cubCookie, CSteamID *pSteamIDUser );
    bool SendUserConnectAndAuthenticate( uint32 unIPClient, const void *pvAuthBlob, uint32 cubAuthBlobSize, CSteamID *pSteamIDUser );

    CSteamID fakeUser();
    
    Auth_Data getTicketData( void *pTicket, int cbMaxTicket, uint32 *pcbTicket, bool add_session_header = false);
};

#endif // AUTH_INCLUDE_H
